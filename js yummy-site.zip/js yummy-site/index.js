let menuListbar = document.getElementById('menuListbar')
let menu = [
    {title:'Home', link: 'home.htm'},
    {title:'About', link: 'About.htm'},
    {title:'Menu', link: 'Menu.htm'},
    {title:'Events', link: 'Events.htm'},
    {title:'Chefs', link: 'Chefs.htm'},
    {title:'Gallery', link: 'Gallery.htm'},
    {title:'Dropdown', link: 'Dropdown.htm'},
    {title:'Contact', link: 'Contact.htm'}
]

menu.map(item => {
    menuListbar.innerHTML += ` <li style="padding: 15px 14px;">${item.title}</li> `
})  


let aboutBlock = document.getElementById('aboutBlock')
let AboutData = [
    {  subTitle: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        ulsecim1: ' Ullamco laboris nisi ut aliquip ex ea commodo consequat.',
        ulsecim2: 'Duis aute irure dolor in reprehenderit in voluptate velit.',
        ulsecim3: 'Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.',
        aboutContent: 'Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident',
        aboutImg1: 'img/about.jpg',
        aboutImg2: 'img/about-2.jpg',
        contact: '+1 5589 55488 55'
    }
]

AboutData.map(item => { 
    aboutBlock.innerHTML += `
    <div  style="display: flex;">
                        <div style="padding: 0 12px; width: 60%;">
                            <div>
                                <img style="max-width: 100%; padding: 0 0 24px;" src="${item.aboutImg1}" alt="">
                            </div>
                            <div style="border: 4px solid #212529; padding: 7px;">
                                <h3 style="text-align: center; font-size: x-large;">Book a Table</h3>
                                <p style="color: #CE1212; font-size: x-large; font-weight: bold; text-align: center;">${item.contact}</p>
                            </div>
                        </div>
                        <div style="padding: 0 0 0 48px; width: 40%;">
                            <p style="color: #7f7f90; font-size: larger; font-style: italic;">${item.subTitle}</p>
                            <ul style="list-style: none;">
                                <li style="padding:0 0 10px;">
                                    <i style="color: white; background-color: #CE1212; border-radius: 50%; padding: 3px; font-size: small;" class="fa-solid fa-check"></i>
                                    <span>${item.ulsecim1}</span>
                                </li>
                                <li style="padding:0 0 10px;">
                                    <i style="color: white; background-color: #CE1212; border-radius: 50%; padding: 3px; font-size: small;" class="fa-solid fa-check"></i>
                                    <span>${item.ulsecim2}</span>
                                </li>
                                <li style="padding:0 0 10px;">
                                    <i style="color: white; background-color: #CE1212; border-radius: 50%; padding: 3px; font-size: small;" class="fa-solid fa-check"></i>
                                    <span>${item.ulsecim3}</span>
                                </li>
                            </ul>
                            <p style="padding-bottom: 10px;">${item.aboutContent} </p>
                            <div>
                                <img style="max-width: 100%;" src="${item.aboutImg2}" alt="">
                            </div>
                        </div>
                    </div>
    `
})

let cartBlock = document.getElementById('cartBlock')
let cartList = [
    {
        subTitle: 'Why Choose Yummy',
        subAbout: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit Asperiores dolores sed et. Tenetur quia eos. Autem tempore quibusdam vel necessitatibus optio ad corporis.',
        ulTitle1: 'Corporis voluptates officia eiusmod',
        ulTitle2: 'Ullamco laboris ladore lore pan',
        ulTitle3: 'Labore consequatur incidid dolore',
        ulAbout1: 'Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip',
        ulAbout2: 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt',
        ulAbout3: 'Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere',
    }
]

cartList.map(item =>{
    cartBlock.innerHTML+= `
    <div style="background-color: #f2f2f2; display: flex; gap: 20px; padding: 50px 70px;">
                <div style="background-color: #CE1212; color: white;padding: 30px; width: 860px; height: 350px;">
                    <h3 style="font-size: 30px;">${item.subTitle}</h3>
                    <p style="font-size: 19px;">${item.subAbout}</p>
                    <button style="cursor: pointer; color: white;padding: 13px; background-color: #e95c5cb5; border-radius: 20px;border: 0 solid;margin-left: 70px;">Learn more <i class="fa-solid fa-angle-right"></i></button>
                </div>

                <div style="padding: 30px; background-color: white; text-align: center;">
                    <div style="padding-top: 40px;">
                        <i style="color: #CE1212;padding: 20px;font-size: xx-large;border-radius: 50%; background-color: #f2d5d5c0;" class="fa-regular fa-clipboard"></i>
                    </div>
                    <h4 style="font-size: 19px;">${item.ulTitle1}</h4>
                    <p style="color: #7f7f90;font-size: 17px;">${item.ulAbout1}</p>
                </div>

                <div style="padding: 30px; background-color: white; text-align: center;">
                    <div style="padding-top: 40px;">
                        <i style="color: #CE1212;padding: 20px;font-size: xx-large;border-radius: 50%; background-color: #f2d5d5c0;" class="fa-regular fa-gem"></i>
                    </div>
                    <h4 style="font-size: 19px;">${item.ulTitle2}</h4>
                    <p style="color: #7f7f90;font-size: 17px;">${item.ulAbout2}</p>
                </div>

                <div style="padding: 30px; background-color: white; text-align: center;">
                    <div style="padding-top: 40px;">
                        <i style="color: #CE1212;padding: 20px;font-size: xx-large;border-radius: 50%; background-color: #f2d5d5c0;" class="fa-solid fa-check"></i>
                    </div>
                    <h4 style="font-size: 19px;">${item.ulTitle3}</h4>
                    <p style="color: #7f7f90;font-size: 17px;">${item.ulAbout3}</p>
                </div>
            </div>
    `
})


let mealBlock = document.getElementById('mealBlock')
let mealList = [
    {
        mealTitle1: 'Magnam Tiste',
        mealTitle2: 'Aut Luia',
        mealTitle3: 'Est Eligendi',
        mealTitle4: 'Eos Luibusdam',
        mealTitle5: 'Eos Luibusdam',
        mealTitle6: 'Laboriosam Direva',
        mealAbout: 'Lorem, deren, trataro, filede, nerada',
        mealPrice1: '$5.95',
        mealPrice2: '$14.95',
        mealPrice3: '$8.95',
        mealPrice4: '$12.95',
        mealPrice5: '$12.95',
        mealPrice6: '$9.95',
        mealImg1: 'img/menu-item-1.png',
        mealImg2: 'img/menu-item-2.png',
        mealImg3: 'img/menu-item-3.png',
        mealImg4: 'img/menu-item-4.png',
        mealImg5: 'img/menu-item-5.png',
        mealImg6: 'img/menu-item-6.png'
    }
]

mealList.map(item =>{
    mealBlock.innerHTML += `
    <div style="display: flex;flex-wrap: wrap;">
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg1}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle1}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice1}</p>
                            </div>
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg2}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle2}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice2}</p>
                            </div>
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg3}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle3}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice3}</p>
                            </div>
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg4}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle4}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice4}</p>
                            </div>
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg5}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle5}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice5}</p>
                            </div>
                            <div style="padding: 0 60px 60px 60px;">
                                <img src="${item.mealImg6}" style="width: 250px;height: 250px;" alt="">
                                <h1 style="text-align: center; color: #37373F;">${item.mealTitle6}</h1>
                                <p style="text-align: center; color: #7f7f90;">${item.mealAbout}</p>
                                <p style="text-align: center; color: #CE1212; font-size: 22px; font-weight: bold">${item.mealPrice6}</p>
                            </div>
                            
                        </div>
    `
})




let chefBlock = document.getElementById('chefBlock')
let chefList = [
    {
        chefTitle1: 'Walter White',
        chefTitle2: 'Sarah Jhonson',
        chefTitle3: 'William Anderson',
        chefAbout1: 'Velit aut quia fugit et et. Dolorum ea voluptate vel tempore tenetur ipsa quae aut. Ipsum exercitationem iure minima enim corporis et voluptate.',
        chefAbout2: 'Quo esse repellendus quia id. Est eum et accusantium pariatur fugit nihil minima suscipit corporis. Voluptate sed quas reiciendis animi neque sapiente.',
        chefAbout3: 'Vero omnis enim consequatur. Voluptas consectetur unde qui molestiae deserunt. Voluptates enim aut architecto porro aspernatur molestiae modi.',
        chefname1: 'Master Chef',
        chefname2: 'Patissier',
        chefname3: 'Cook',
        chefImg1: 'img/chefs-1.jpg',
        chefImg2: 'img/chefs-2.jpg',
        chefImg3: 'img/chefs-3.jpg'
    }
]
chefList.map(item =>{
    chefBlock.innerHTML += `
        <div style="display: flex; justify-content: center; gap: 20px; padding: 0 60px 40px">
                        <div style="background-color: white;">
                            <img style="width: 373px;" src="${item.chefImg1}" alt="">
                            <div style="text-align: center;padding: 10px 15px 20px;">
                                <h1>${item.chefTitle1}</h1>
                                <h3 style="color: #7f7f90;">${item.chefname1}</h3>
                                <p style="color: rgb(66, 64, 64); font-style: italic;">${item.chefAbout1}</p>
                            </div>
                        </div>
                        <div style="background-color: white;">
                            <img style="width: 373px;" src="${item.chefImg2}" alt="">
                            <div style="text-align: center;padding: 10px 15px 20px;">
                                <h1>${item.chefTitle2}</h1>
                                <h3 style="color: #7f7f90;">${item.chefname2}</h3>
                                <p style="color: rgb(66, 64, 64); font-style: italic;">${item.chefAbout2}</p>
                            </div>
                        </div>
                        <div style="background-color: white;">
                            <img style="width: 373px;" src="${item.chefImg3}" alt="">
                            <div style="text-align: center;padding: 10px 15px 20px;">
                                <h1>${item.chefTitle3}</h1>
                                <h3 style="color: #7f7f90;">${item.chefname3}</h3>
                                <p style="color: rgb(66, 64, 64); font-style: italic;">${item.chefAbout3}</p>
                            </div>
                        </div>
                    </div>
    `
})